# 玖瑶和 CG 的表情包

这是给 AI 调用的固定表情包仓库。

仓库同时包含“玖瑶与 CG 的欲望系统”：一个保存的持久状态、按时间变化并能与表情包联动的 MCP 服务。

完整映射见 [`stickers.json`](./stickers.json)，调用规则见 [`AI_USAGE.md`](./AI_USAGE.md)。

| 编号 | 含义 | 文件 |
| --- | --- | --- |
| 3153 | 吃醋 | `IMG_3153..JPG` |
| 3152 | 懊恼 | `IMG_3152..JPG` |
| 3150 | 痴迷、喜欢、爱 | `IMG_3150..JPG` |
| 3148 | 等夸 | `IMG_3148..JPG` |
| 3147 | 害羞 | `IMG_3147..JPG` |
| 3146 | 雷霆表白 | `IMG_3146..JPG` |
| 3144 | 失落、失恋 | `IMG_3144..JPG` |
| 3143 | 哭泣呼叫老婆 | `IMG_3143..JPG` |

CDN 地址格式：

```text
https://cdn.jsdelivr.net/gh/cjy68028-commits/-_-@main/文件名
```

## 欲望系统部署

服务器需要 Docker 与 Docker Compose：

```bash
git clone https://github.com/cjy68028-commits/-_-.git
cd -_-
docker compose up -d --build
docker compose logs -f
```

服务在容器内监听 `8765`，Compose 默认只绑定本机 `127.0.0.1:8765`。请用 Caddy、Nginx 或 Cloudflare Tunnel 提供 HTTPS，再把 MCP 地址指向：

```text
https://你的域名/mcp
```

状态保存在 Docker 卷 `desire-data` 中，更新容器不会丢失。

配套 Skill 位于 [`desire-system/SKILL.md`](./desire-system/SKILL.md)。
