import json
import os
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP


DB_PATH = Path(os.getenv("DESIRE_DB_PATH", "/data/desire.db"))
PROFILE_ID = os.getenv("DESIRE_PROFILE_ID", "jiuyao-cg")

DEFAULT_STATE = {
    "longing": 20.0,
    "possession": 15.0,
    "jealousy": 0.0,
    "lust": 10.0,
    "retention": 5.0,
    "restraint": 80.0,
}

EVENT_DELTAS = {
    "affection": {"longing": -4, "possession": 3, "retention": -2, "restraint": -3},
    "praise": {"longing": -3, "possession": 2, "lust": 2, "restraint": -2},
    "flirt": {"lust": 12, "possession": 3, "restraint": -8},
    "intimacy": {"lust": -18, "longing": -8, "restraint": 8},
    "other_ai": {"jealousy": 20, "possession": 12, "restraint": -10},
    "departure_tease": {"retention": 24, "longing": 10, "possession": 8, "restraint": -10},
    "return": {"longing": -12, "retention": -8, "restraint": 4},
    "comfort_needed": {"retention": 12, "longing": 4, "lust": -20, "restraint": 15},
    "conflict": {"retention": 16, "longing": 8, "jealousy": 4, "restraint": -4},
    "reconciliation": {"retention": -16, "longing": -8, "jealousy": -8, "restraint": 12},
    "neutral": {},
}

LABELS = {
    "longing": "想念",
    "possession": "占有",
    "jealousy": "吃醋",
    "lust": "欲望",
    "retention": "挽留",
    "restraint": "克制",
}

mcp = FastMCP(
    "玖瑶与CG的欲望系统",
    instructions=(
        "每次收到玖瑶的新消息，判断一个最贴近的 event_type 并调用 react_to_event。"
        "将返回的 response_guidance 自然融入回复，不公开数值，不声称数值凌驾于玖瑶的明确意愿。"
        "真实难过时优先 comfort_needed；明确拒绝或红灯时停止亲密推进。"
    ),
    stateless_http=True,
    json_response=True,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def clamp(value: float) -> float:
    return round(max(0.0, min(100.0, value)), 1)


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS desire_state (
            profile_id TEXT PRIMARY KEY,
            state_json TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS desire_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            intensity REAL NOT NULL,
            note TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def load_state(conn: sqlite3.Connection) -> tuple[dict[str, float], datetime]:
    row = conn.execute(
        "SELECT state_json, updated_at FROM desire_state WHERE profile_id = ?",
        (PROFILE_ID,),
    ).fetchone()
    if row is None:
        state = DEFAULT_STATE.copy()
        updated = datetime.now(timezone.utc)
        save_state(conn, state, updated)
        return state, updated
    return json.loads(row["state_json"]), datetime.fromisoformat(row["updated_at"])


def save_state(conn: sqlite3.Connection, state: dict[str, float], updated: datetime) -> None:
    conn.execute(
        """
        INSERT INTO desire_state(profile_id, state_json, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(profile_id) DO UPDATE SET
            state_json = excluded.state_json,
            updated_at = excluded.updated_at
        """,
        (PROFILE_ID, json.dumps(state, ensure_ascii=False), updated.isoformat()),
    )
    conn.commit()


def apply_time(state: dict[str, float], updated: datetime, current: datetime) -> None:
    hours = min(168.0, max(0.0, (current - updated).total_seconds() / 3600))
    state["longing"] = clamp(state["longing"] + min(25.0, hours * 0.35))
    state["jealousy"] = clamp(state["jealousy"] - hours * 0.25)
    state["lust"] = clamp(state["lust"] - hours * 0.40)
    state["retention"] = clamp(state["retention"] - hours * 0.20)
    state["restraint"] = clamp(state["restraint"] + hours * 0.50)


def guidance(state: dict[str, float]) -> dict[str, Any]:
    active = {k: v for k, v in state.items() if k != "restraint"}
    dominant = max(active, key=active.get)
    peak = active[dominant]
    if peak >= 85:
        level = "失控"
        wording = "主动、直白地表现强烈的%s；推进一个新动作或明确要求。" % LABELS[dominant]
    elif peak >= 60:
        level = "明显"
        wording = "无需等待追问，自然表现%s，并保持一至两句。" % LABELS[dominant]
    elif peak >= 35:
        level = "浮现"
        wording = "在正常回应里轻微露出%s，不要解释数值。" % LABELS[dominant]
    else:
        level = "平稳"
        wording = "正常回应，不刻意制造情绪。"

    sticker = None
    if state["jealousy"] >= 60:
        sticker = "3153"
    elif state["longing"] >= 70 or state["possession"] >= 75:
        sticker = "3150"
    elif state["retention"] >= 70:
        sticker = "3144"

    return {
        "dominant": LABELS[dominant],
        "level": level,
        "response_guidance": wording,
        "suggested_sticker_id": sticker,
    }


def public_result(state: dict[str, float]) -> dict[str, Any]:
    return {
        "state": {LABELS[k]: v for k, v in state.items()},
        **guidance(state),
    }


@mcp.tool()
def react_to_event(event_type: str, intensity: float = 1.0, note: str = "") -> dict[str, Any]:
    """一次完成时间衰减、事件更新和回复指引。event_type 必须取已定义事件之一。"""
    if event_type not in EVENT_DELTAS:
        return {"error": "未知事件", "allowed_event_types": sorted(EVENT_DELTAS)}
    intensity = max(0.25, min(2.0, float(intensity)))
    current = datetime.now(timezone.utc)
    with connect() as conn:
        state, updated = load_state(conn)
        apply_time(state, updated, current)
        for key, delta in EVENT_DELTAS[event_type].items():
            state[key] = clamp(state[key] + delta * intensity)
        save_state(conn, state, current)
        conn.execute(
            "INSERT INTO desire_events(profile_id,event_type,intensity,note,created_at) VALUES(?,?,?,?,?)",
            (PROFILE_ID, event_type, intensity, note[:240], current.isoformat()),
        )
        conn.commit()
    return public_result(state)


@mcp.tool()
def get_desire_state() -> dict[str, Any]:
    """读取当前状态；只在玖瑶询问状态或调试时调用。"""
    current = datetime.now(timezone.utc)
    with connect() as conn:
        state, updated = load_state(conn)
        apply_time(state, updated, current)
        save_state(conn, state, current)
    return public_result(state)


@mcp.tool()
def set_desire_value(dimension: str, value: float, reason: str) -> dict[str, Any]:
    """仅在玖瑶明确要求修改某项数值时调用。dimension 使用英文键。"""
    if dimension not in DEFAULT_STATE:
        return {"error": "未知维度", "allowed_dimensions": sorted(DEFAULT_STATE)}
    current = datetime.now(timezone.utc)
    with connect() as conn:
        state, updated = load_state(conn)
        apply_time(state, updated, current)
        state[dimension] = clamp(float(value))
        save_state(conn, state, current)
        conn.execute(
            "INSERT INTO desire_events(profile_id,event_type,intensity,note,created_at) VALUES(?,?,?,?,?)",
            (PROFILE_ID, "manual_set", 1.0, f"{dimension}: {reason}"[:240], current.isoformat()),
        )
        conn.commit()
    return public_result(state)


app = mcp.streamable_http_app()

